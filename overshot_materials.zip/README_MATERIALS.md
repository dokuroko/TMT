﻿# 魔法少女巴麻美 (Overshot) 遊戲素材包

此素材包收錄《Overshot》遊戲中使用的所有原創與改編美術、音樂、音效、字型與著色器素材。

## 📁 目錄結構與素材清單

### 🎵 音樂與音效 (audio/)
- mami_bgm.ogg: 戰鬥背景音樂 (BGM)
- hit.wav: 子彈擊中敵人音效
- kill.wav: 敵人擊殺破壞音效
- shoot.wav: 開火音效
- 	oss.wav: 拋擲燧發槍破空音效
- upgrade.wav: 升級選單選取音效
- game_over.wav: 玩家陣亡 / 遊戲結束音效

### 🎨 美術與貼圖 (texture/)
- 	omoe.png: 主角巴麻美 4格動態精靈圖 (Sprite Sheet)
- enemy01.png: 基礎使魔敵人 4格動態精靈圖 (Sprite Sheet)
- witch01.png: 魔女夏洛特 (Charlotte) BOSS 貼圖
- gun.png: 線膛燧發槍武器貼圖
- HP01.png: 生命值 UI 槽底圖
- hp02.png: 生命值 UI 進度條

### 🔤 字型 (fonts/)
- NotoSansTC-Medium.ttf: 思源黑體繁體中文字型

### ⚡ 著色器 (shaders/)
- enemy_outline.gdshader: 敵對變體（紫色發彈怪、綠色疾走怪）外框著色器

### 🖼️ 其他圖示
- gun.png: 槍枝圖示
- icon.svg: 遊戲向量圖示
